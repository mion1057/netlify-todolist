
import '../css/TodoInsert.css';
import { Component } from 'react';

class TodoInsert extends Component{
  constructor(props) {
    super(props)
    this.state = {
        text:''
    }
  }

  textChange = (e) => {
      console.log(e.target.value)
      this.setState({
          text:e.target.value
      })
  }
    
  onInsert = () => {
    const {text}=this.state
    alert("추가(TodoInsert)")
    alert(text)
    this.props.onInsert(text);
  }
    
  render() {
    return (
      <div className='todo-insert'>
           <input type='text' onChange={this.textChange}/>
           <button onClick={this.onInsert}>추가</button>
      </div>
    )
  }
}
export default TodoInsert;
